﻿/*
 Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("codesnippet","lv",{button:"Ievietot koda fragmentu",codeContents:"Koda saturs",emptySnippetError:"Koda fragments nevar būt tukšs.",language:"Valoda",title:"Koda fragments",pathName:"koda fragments"});